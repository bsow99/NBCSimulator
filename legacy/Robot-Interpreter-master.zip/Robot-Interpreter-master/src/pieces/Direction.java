/**
 * 
 */
package weizhuo;

/**
 * @author weizhuowu
 *
 */
public enum Direction {

	WEST, SOUTH, NORTH, EAST;
}
