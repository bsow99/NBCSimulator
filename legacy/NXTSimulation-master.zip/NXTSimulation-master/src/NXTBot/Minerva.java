/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package NXTBot;

/**
 *
 * @author rey
 */
public class Minerva extends NXTBotFrame {
    public Minerva(double x, double y, double angle) {
        super(x, y, 0);
        name = "Isode";
        model = "AGL-X360";
    }

}