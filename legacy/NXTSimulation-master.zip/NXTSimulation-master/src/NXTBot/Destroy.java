/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package NXTBot;

/**
 *
 * @author rey
 */
public class Destroy extends NXTBotFrame {
    public Destroy(double x, double y, double angle) {
        super(x, y, 0);
        name = "Dominion";
        model = "IAM-X666"; // Integrated Automonous Machine
    }
}
