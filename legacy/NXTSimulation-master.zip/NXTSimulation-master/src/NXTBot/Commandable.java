package NXTBot;

public interface Commandable {
    public void handleCommand(int command);
}
