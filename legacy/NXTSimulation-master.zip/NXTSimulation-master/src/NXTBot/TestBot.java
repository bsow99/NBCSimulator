/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package NXTBot;

/**
 *
 * @author rey
 */
public class TestBot extends NXTBotFrame {
    public TestBot(double x, double y, double angle) {
        super(x, y, angle);
        name = "testament";
        model = "";
    }

}
