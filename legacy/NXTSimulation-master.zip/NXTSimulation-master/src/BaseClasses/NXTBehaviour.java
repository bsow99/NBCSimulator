/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package BaseClasses;

/**
 *
 * @author rey
 */
public abstract class NXTBehaviour extends Behaviour {
    
    public void Update() {}
    
}
