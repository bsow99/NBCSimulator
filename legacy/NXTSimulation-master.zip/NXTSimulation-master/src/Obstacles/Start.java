/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package Obstacles;

import java.awt.Graphics2D;

/**
 *
 * @author rey
 */
public class Start extends Structure {

    @Override
    public void paint(Graphics2D g) {
    }

}
