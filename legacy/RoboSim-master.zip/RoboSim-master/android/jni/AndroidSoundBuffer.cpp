/*
 *  AndroidSoundBuffer.cpp
 *  mindstormssimulation
 *
 *  Created by Torsten Kammer on 20.01.11.
 *  Copyright 2011 __MyCompanyName__. All rights reserved.
 *
 */

#include "AndroidSoundBuffer.h"

SoundBuffer::~SoundBuffer()
{
	//TODO: Implement sound on Android
}

SoundBuffer::SoundBuffer(const char *WAVfilename) throw(std::runtime_error)
{
	//TODO: Implement sound on Android
}

SoundBuffer::SoundBuffer(unsigned frequency, unsigned time)
{
	//TODO: Implement sound on Android
}