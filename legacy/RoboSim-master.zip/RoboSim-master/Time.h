/*
 *  Time.h
 *  mindstormssimulation
 *
 *  Created by Torsten Kammer on 27.11.10.
 *  Copyright 2010 __MyCompanyName__. All rights reserved.
 *
 */

#ifdef __cplusplus
extern "C" {
#endif

void startTimeCount();
unsigned millisecondsSinceStart();

#ifdef __cplusplus
}
#endif
