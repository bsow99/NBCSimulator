RoboSim
=======

A Lego Mindstorms 2.0 simulator for Mac OS X, Windows, Android and iOS. 

You can download compiled versions at:

<http://schuelerlabor.informatik.rwth-aachen.de/simulator>

RoboSim is released under GPL version 2 or later.
Developed by Torsten Kammer in the Leraning Technologies Research Group (RWTH Aachen University), originally as a Bachelor thesis and further development as a student worker.